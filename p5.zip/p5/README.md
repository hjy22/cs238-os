gcloud compute scp --recurse "/Users/huangjiayi/Documents/003UCI/learn/cs238-os/p5" instance-1:

sudo wget http://ipv4.download.thinkbroadband.com/512MB.zip

sudo ./cs238 /dev/loop11

valgrind --leak-check=full ./cs238